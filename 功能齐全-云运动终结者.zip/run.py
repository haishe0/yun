import base64
import random
import time
import requests
import json
from pyDes import des, CBC, PAD_PKCS5
from pywebio.output import *
from pywebio import config
from pywebio import start_server
from pywebio.input import *

config(title="云运动终结者")
default_iv = '\1\2\3\4\5\6\7\x08'
yun_host = "http://81.70.49.179:8080"
my_host = "http://119.45.6.133:8080"
default_key = "YUNZHIEE"
my_app_edition = "2.1.1"
my_key = "aa0e0eda85fe1c81f708c210e1fff542"  # 地图key
my_device_name = "Redmi(K40)"
my_sys_edition = "12"
my_point = "118.308302,32.273387"
exclude_points = []

single_mileage_min_offset = float("5")
single_mileage_max_offset = float("-5")
cadence_min_offset = int("60")
cadence_max_offset = int("-100")
split_count = int("10")

my_device_id = ""
schoolId = "106"


def des_encrypt(s, key=default_key, iv=default_iv):
    secret_key = key
    k = des(secret_key, CBC, iv, pad=None, padmode=PAD_PKCS5)
    en = k.encrypt(s, padmode=PAD_PKCS5)
    return base64.b64encode(en)


def des_decrypt(s, key=default_key, iv=default_iv):
    secret_key = key
    k = des(secret_key, CBC, iv, pad=None, padmode=PAD_PKCS5)
    de = k.decrypt(base64.b64decode(s), padmode=PAD_PKCS5)
    return de


class Yun:
    my_token = ""
    sex = 0

    def __init__(self):
        pass

    def login(self, user_name, password):
        data = {
            'password': password,
            'schoolId': "106",
            'userName': user_name,
            'type': "1"
        }
        resp = self.default_post('/login/appLogin', json.dumps(data))
        j = json.loads(resp)
        if j['code'] == 200:
            put_text("登录成功")
            return j['data']['token']
        else:
            put_text(j['msg'])
            return ''

    def sign_out(self):
        j = json.loads(self.default_post("/login/signOut", ""))
        if j['code'] == 200:
            put_text("退出登录成功")

    def getHomeRunInfo(self):
        # 根据性别确认男/女跑步，男0，女1
        put_text("男"if self.sex==0 else "女")
        data = json.loads(self.default_post("/run/getHomeRunInfo", ""))['data']['cralist'][self.sex]
        self.raType = data['raType']
        self.raId = data['id']
        self.schoolId = data['schoolId']
        self.raRunArea = data['raRunArea']
        self.raDislikes = data['raDislikes']
        self.raMinDislikes = data['raDislikes']

        self.myLikes = 4  # 疑似打卡点书

        self.raSingleMileageMin = data['raSingleMileageMin'] + single_mileage_min_offset
        self.raSingleMileageMax = data['raSingleMileageMax'] + single_mileage_max_offset
        self.raCadenceMin = data['raCadenceMin'] + cadence_min_offset
        self.raCadenceMax = data['raCadenceMax'] + cadence_max_offset
        points = data['points'].split('|')
        put_text('开始标记打卡点...')
        for exclude_point in exclude_points:
            try:
                points.remove(exclude_point)
                put_text("成功删除打卡点", exclude_point)
            except ValueError:
                put_text("打卡点", exclude_point, "不存在")
        random_points = random.sample(points, self.raDislikes)
        self.manageList = []
        self.now_dist = 0  # 疑似
        self.now_time = round(random.uniform(-3, 5), 2)  # 时间 随机取整数   round(random.uniform(-5,10), 2)
        self.task_list = []
        self.task_count = 0  # 疑似
        for point_index, point in enumerate(random_points):
            # if self.now_dist / 1000 < min_distance or self.myLikes < self.raMinDislikes:
            if self.myLikes < self.raMinDislikes:
                self.manageList.append({
                    'point': point,
                    'marked': 'Y',
                    'index': point_index
                })
                self.add_task(point)
                self.myLikes += 1
            else:
                self.manageList.append({
                    'point': point,
                    'marked': 'N',
                    'index': ''
                })

        if self.now_dist / 1000 < min_distance:
            put_text('公里数不足' + str(min_distance) + '公里，将自动回跑...')
            index = 0
            while self.now_dist / 1000 < min_distance:
                self.add_task(self.manageList[index]['point'])
                index = (index + 1) % self.raDislikes

        put_text('打卡点标记完成！本次将打卡' + str(self.myLikes) + '个点，处理' + str(len(self.task_list)) + '个点，总计'
                 + format(self.now_dist / 1000, '.2f')
                 + '公里，将耗时' + str(self.now_time // 60) + '分' + str(round((self.now_time % 60), 2)) + '秒')
        # 这三个只是初始化，并非最终值
        self.recordStartTime = ''
        self.crsRunRecordId = 0  # 疑似
        self.userName = ''

    def default_post(self, router, data, headers=None, m_host=None):
        if m_host is None:
            m_host = my_host
        url = m_host + router
        if headers is None:
            headers = {
                'token': self.my_token,
                'isApp': 'app',
                'deviceId': my_device_id,
                'version': my_app_edition,
                'platform': 'android',
                'Content-Type': 'text/plain; charset=utf-8',
                'Connection': 'Keep-Alive',
                'Accept-Encoding': 'gzip',
                'User-Agent': 'okhttp/3.12.0'
            }
        req = requests.post(url=url, data=des_encrypt(data), headers=headers)
        return req.text

    # 每10个路径点作为一组splitPoint;
    # 若最后一组不满10个且多于1个，则将最后一组中每两个点位分取10点（含终点而不含起点），作为一组splitPoint
    # 若最后一组只有1个（这种情况只会发生在len(splitPoints) > 0），则将已插入的最后一组splitPoint的最后一个点替换为最后一组的点
    def add_task(self, point):
        if not self.task_list:
            origin = my_point
        else:
            origin = self.task_list[-1]['originPoint']
        data = {
            'key': my_key,
            'origin': origin,
            'destination': point
        }
        resp = requests.get("https://restapi.amap.com/v4/direction/bicycling", params=data)
        j = json.loads(resp.text)
        split_points = []
        split_point = []
        for path in j['data']['paths']:
            self.now_dist += path['distance']
            self.now_time += round(random.uniform(1, 2.5), 4) * path['duration']  # random.uniform(1.5,2.5)  随机取小数
            path['steps'][-1]['polyline'] += ';' + point
            for step in path['steps']:
                polyline = step['polyline']
                points = polyline.split(';')
                for p in points:
                    split_point.append({
                        'point': p,
                        'runStatus': '1',
                        'speed': format(random.uniform(self.raSingleMileageMin, self.raSingleMileageMax), '.2f')
                    })
                    if len(split_point) == split_count:
                        split_points.append(split_point)
                        self.task_count = self.task_count + 1
                        split_point = []

        if len(split_point) > 1:
            b = split_point[0]['point']
            for i in range(1, len(split_point)):
                new_split_point = []
                a = b
                b = split_point[i]['point']
                a_split = a.split(',')
                b_split = b.split(',')
                a_x = float(a_split[0])
                a_y = float(a_split[1])
                b_x = float(b_split[0])
                b_y = float(b_split[1])
                d_x = (b_x - a_x) / split_count
                d_y = (b_y - a_y) / split_count
                for j in range(0, split_count):
                    new_split_point.append({
                        'point': str(a_x + (j + 1) * d_x) + ',' + str(a_y + (j + 1) * d_y),
                        'runStatus': '1',
                        'speed': format(random.uniform(self.raSingleMileageMin, self.raSingleMileageMax), '.2f')
                    })
                split_points.append(new_split_point)
                self.task_count = self.task_count + 1
        elif len(split_point) == 1:
            split_points[-1][-1] = split_point[0]

        self.task_list.append({
            'originPoint': point,
            'points': split_points
        })

    def start(self):
        data = {
            'raRunArea': self.raRunArea,
            'raType': self.raType,
            'raId': self.raId
        }
        j = json.loads(self.default_post('/run/start', json.dumps(data)))
        if j['code'] == 200:
            self.recordStartTime = j['data']['recordStartTime']
            self.crsRunRecordId = j['data']['id']
            self.userName = j['data']['studentId']
            put_text(
                "【 " + time.strftime("%Y 年 %H 点 %M 分 %S 秒", time.localtime()) + " 】" + "           " + "云运动任务创建成功！")

    def split(self, points):
        data = {
            'cardPointList': points,
            'crsRunRecordId': self.crsRunRecordId,
            'schoolId': self.schoolId,
            'userName': self.userName
        }
        headers = {
            'Content-Type': 'text/plain;charset=utf-8',
            'Connection': 'Keep-Alive',
            'Accept-Encoding': 'gzip',
            'User-Agent': 'okhttp/3.12.0'
        }
        resp = self.default_post("/run/splitPoints", data=json.dumps(data), headers=headers)
        put_text('  ' + resp)

    def do(self):
        sleep_time = self.now_time / (self.task_count + 1)
        put_text('等待' + format(sleep_time, '.2f') + '秒...')
        # time.sleep(sleep_time)
        for task_index, task in enumerate(self.task_list):
            put_text('开始处理第' + str(task_index + 1) + '个点...')
            for split_index, split in enumerate(task['points']):
                self.split(split)
                put_text('  第' + str(split_index + 1) + '次splitPoint发送成功！等待' + format(sleep_time, '.2f') + '秒...')
                # time.sleep(sleep_time)
            put_text('第' + str(task_index + 1) + '个点处理完毕！')

    def finish(self):
        put_text('发送结束信号...')
        data = {
            'recordMileage': format(self.now_dist / 1000, '.2f'),
            'recodeCadence': random.randint(self.raCadenceMin, self.raCadenceMax),
            'recodePace': format(self.now_time / 60 / (self.now_dist / 1000), '.2f'),
            'deviceName': my_device_name,
            'sysEdition': my_sys_edition,
            'appEdition': my_app_edition,
            'raIsStartPoint': 'Y',
            'raIsEndPoint': 'Y',
            'raRunArea': self.raRunArea,
            'recodeDislikes': self.myLikes,
            'raId': self.raId,
            'raType': self.raType,
            'id': self.crsRunRecordId,
            'duration': self.now_time,
            'recordStartTime': self.recordStartTime,
            'manageList': self.manageList
        }
        resp = self.default_post("/run/finish", json.dumps(data))
        put_text(resp)


def yyd():
    global my_device_id, min_distance
    my_key = "aa0e0eda85fe1c81f708c210e1fff542"  # 地图key
    my_device_id = ""
    min_distance = ""

    try:
        if my_key == '':
            my_key = input("未能获取高德地图Key。请输入：")
        if my_device_id == '':
            select_res = select("未能获取DeviceId，请选择：", ['输入', '生成'])
            if select_res == '输入':
                my_device_id = input("请输入15位DeviceId:")
            else:
                my_device_id = ''.join(str(random.randint(1, 9)) for i in range(15))
        client = Yun()
        my_token = ""
        select_res = select("未能获取Token，请选择：", ['输入', '登录', '退出'])
        if select_res == '输入':
            my_host = "http://119.45.6.133:8080"
            my_token = input("请输入用户Token:")
            client.my_token = my_token
        elif select_res == '登录':
            my_host = "http://119.45.6.133:8080"
            s_id = "106"
            while my_token == '':
                data = input_group("请输入相关信息！", [
                    input('学号：', name='name'),
                    input('密码：', name='word')
                ])
                name = data['name']
                word = data['word']
                client.my_token = client.login(name, word, s_id)
        if min_distance == '':
            select_res = select("未能获取最低公里数，请选择：", ['1.6', '2', '3.5', '5', '自己输入'])
            if select_res == '1.6':
                min_distance = float("1.6")
            elif select_res == '2':
                min_distance = float("2")
            elif select_res == '3.5':
                min_distance = float("3.5")
            elif select_res == '5':
                min_distance = float("5")
            else:
                min_distance = input('最低公里数：', type=FLOAT)
        else:
            exit()

        tmp = json.loads(client.default_post("/login/getStudentInfo", ""))
        # 确认性别
        client.sex = tmp["data"]["sex"] - 1
        client.getHomeRunInfo()

        # 下面的这些是输出下信息
        put_text(tmp['data']['nickName'] + "    " + '信息获取成功！')
        put_text("本次最低公里数为：" + str(min_distance) + " km")
        put_text("my_device_id：" + my_device_id)
        put_text("Token：" + my_token)

        select_res = select("未能获取Token，请选择：", ['开始跑步', '退出登录', '结束任务'])
        if select_res == '开始跑步':
            client.start()
            client.do()
            client.finish()
            if input("任务结束！输入yes以退出登录，任意内容结束") == 'yes':
                client.sign_out()
                input()
        elif select_res == '退出登录':
            client.sign_out()
            input()
    except Exception as e:
        put_text('任务失败！检查token、高德地图开发者密钥或网络设置')
        put_text(e)
        input()


if __name__ == '__main__':
    start_server(yyd, 5005)
